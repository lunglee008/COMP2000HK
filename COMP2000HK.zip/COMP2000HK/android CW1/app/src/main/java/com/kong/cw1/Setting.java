package com.kong.cw1;

import org.json.JSONObject;

public class Setting {
    public static JSONObject userJasonObject = new JSONObject();
}